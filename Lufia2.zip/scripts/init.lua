--  Load configuration options up front
ScriptHost:LoadScript("scripts/settings.lua")

Tracker:AddItems("items/items.json")
Tracker:AddMaps("maps/maps.json")
Tracker:AddLocations("locations/locations.json")

if (string.find(Tracker.ActiveVariantUID, "standard")) then
    Tracker:AddLayouts("layouts/standart/tracker.json")
    Tracker:AddLayouts("layouts/standart/standard_broadcast.json")
end
if (string.find(Tracker.ActiveVariantUID, "standart_name")) then
    Tracker:AddLayouts("layouts/standart_name/tracker.json")
    Tracker:AddLayouts("layouts/standart_name/standard_broadcast.json")
end

