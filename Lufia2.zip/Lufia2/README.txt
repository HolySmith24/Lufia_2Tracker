How to use

step 1
put the pack in ...\EmoTracker\packs

step 2
open EmoTracker

step 3
pick the packs 
(if you dont see it unzip it, and you should see the readme.txt in ...\EmoTracker\packs\Lufia2, not like ...\EmoTracker\packs\Lufia2\Lufia2 )

There a broacast view for obs by pressin F2 in the EmoTracker

This is done with bad codding, and i don't know how to auto-track sadly , feel free to make a auto-tracker on it base on this packs